# 👥 Employee Attrition Prediction
A machine learning project predicting employee attrition using HR dataset.

## Features
- Implements Logistic Regression and Random Forest classifiers.
- Dataset: IBM HR Analytics Attrition Dataset (publicly available on Kaggle).
- Encodes categorical variables, normalizes data, and evaluates models.
- Outputs include accuracy, confusion matrix, and feature importance.

## Files
- `notebooks/employee_attrition.ipynb`: Full pipeline in Jupyter Notebook.
- `sample_data/employee_attrition_demo.csv`: Sample HR attrition dataset.
- `requirements.txt`: Python dependencies.
- `outputs/attrition_confusion_demo.png`: Example confusion matrix output.
- `.gitignore`: Ignore unnecessary files.
- `LICENSE`: MIT License.

---
Developed by Ipsha Gautam
